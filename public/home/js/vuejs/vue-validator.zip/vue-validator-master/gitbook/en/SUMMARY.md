# vue-validator documentation

> Validator component for Vue.js 

**[CHANGELOG](https://github.com/vuejs/vue-validator/blob/dev/CHANGELOG.md)**

- [Installation](installation.md)
