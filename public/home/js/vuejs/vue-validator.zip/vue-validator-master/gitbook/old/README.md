# 2.x Docs

- [English](https://github.com/vuejs/vue-validator/tree/2.x/docs/en)
- [Chinese](https://github.com/vuejs/vue-validator/tree/2.x/docs/zh-cn)
- [Japanese](https://github.com/vuejs/vue-validator/tree/2.x/docs/ja)
