<!-- GENERATED FROM SOURCE -->

# vjs.CaptionsButton

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L401](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L401)  

The button component for toggling and selecting captions

---

