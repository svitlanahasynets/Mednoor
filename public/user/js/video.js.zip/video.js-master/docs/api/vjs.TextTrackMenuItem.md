<!-- GENERATED FROM SOURCE -->

# vjs.TextTrackMenuItem

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L194](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L194)  

The specific menu item type for selecting a language within a text track kind

---

