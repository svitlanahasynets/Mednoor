<!-- GENERATED FROM SOURCE -->

# vjs.OffTextTrackMenuItem

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L296](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L296)  

A special menu item for turning of a specific type of text track

---

