<!-- GENERATED FROM SOURCE -->

# vjs.SubtitlesButton

__DEFINED IN__: [src/js/tracks/text-track-controls.js#L433](https://github.com/videojs/video.js/blob/master/src/js/tracks/text-track-controls.js#L433)  

The button component for toggling and selecting subtitles

---

