# Deprecated

See [karol-f/vue-element](https://github.com/karol-f/vue-element) instead.
