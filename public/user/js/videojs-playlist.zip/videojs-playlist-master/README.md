Video.js playlist
===================
A video-js plugin based on [Tim Peterson plugin](https://github.com/tim-peterson/videojs-playlist) with some improvements.
